<?php if(!defined('IN_ZYADS')) exit(); 
TPL::display('header'); ?>
 
<title>广告商</title>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" class="b_bc">
  <tr>
    <td><table width="960" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td height="150" ><img src="<?php echo SRC_TPL_DIR?>/images/a1.jpg" border="0" align="absmiddle" /></td>
        </tr>
      </table></td>
  </tr>
  <tr></tr>
</table>
 <table width="960" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:30px; margin-bottom:30px">
   <tr>
     <td><table width="100%" border="0" cellpadding="0" cellspacing="0">
         <tr>
           <td width="70" height="25"><span class="title">广告商</span></td>
           <td>&nbsp;</td>
         </tr>
         <tr>
           <td class="title_td_1"></td>
           <td class="title_td_2"></td>
         </tr>
     </table></td>
   </tr>
   <tr>
     <td><table width="100%" border="0" cellpadding="0" cellspacing="0">
         <tr>
           <td height="50"> 广告商是广告活动的发布者,是在网上销售或宣传自己产品和服务的商家,是联盟营销广告的提供者。</td>
         </tr>
         <tr>
           <td height="30">&nbsp;</td>
         </tr>
         <tr>
           <td><table width="100%" border="0" cellpadding="0" cellspacing="0">
               <tr>
                 <td width="50" height="80" valign="top"><img src="<?php echo SRC_TPL_DIR?>/images/advertiser_01.jpg" /></td>
                 <td valign="top"><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
                   <tr>
                     <td colspan="2" valign="top" class="a_tit">计费模式--覆盖主流计费模式</td>
                    </tr>
                   <tr>
                     <td width="15" height="45" class="red_dotted"></td>
                     <td>CPM (弹窗付费)、CPC (点击付费)、CPV (显示效果付费)、CPS (成功销售付费)、CPA (有效注册付费)</td>
                    </tr>
                   <tr>
                      <td width="15" height="35" class="red_dotted"></td>
                     <td>多种广告投放方式及计费模式，广站主自由选择，满足投放需求                     </td>
                    </tr>
                 </table>                 </td>
                 <td width="50" valign="top"><img src="<?php echo SRC_TPL_DIR?>/images/advertiser_02.jpg" /></td>
                 <td><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
                   <tr>
                     <td colspan="2" valign="top" class="a_tit">节约成本--开源节流，助力品牌提升</td>
                   </tr>
                   <tr>
                     <td width="15" height="45" class="red_dotted"></td>
                     <td>花费比传统广告低廉数倍的费用，收获比传统广告多数倍的效果！                     </td>
                   </tr>
                   <tr>
                     <td width="15" height="45" class="red_dotted"></td>
                     <td>过万的各种类型的网站资源，迅速帮助企业网站提升访问量和品牌知名度；</td>
                   </tr>
                 </table></td>
               </tr>
               <tr>
                 <td valign="top">&nbsp;</td>
                 <td>&nbsp;</td>
                 <td valign="top">&nbsp;</td>
                 <td>&nbsp;</td>
               </tr>
               <tr>
                 <td valign="top"><img src="<?php echo SRC_TPL_DIR?>/images/advertiser_03.jpg" /></td>
                 <td><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
                   <tr>
                     <td colspan="2" valign="top" class="a_tit">精准投放--把握每一分钱的效益</td>
                   </tr>
                   <tr>
                     <td width="15" height="45" class="red_dotted"></td>
                     <td>按照地域、时间、网站类型、星期等多种定向方式投放广告，实现广告精准投放                     </td>
                   </tr>
                   <tr>
                     <td width="15" height="35" class="red_dotted"></td>
                     <td>设置广告对每位用户的展示方式，粒度精确到每天、每小时</td>
                   </tr>
                 </table></td>
                 <td valign="top"><img src="<?php echo SRC_TPL_DIR?>/images/advertiser_04.jpg" /></td>
                 <td><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
                   <tr>
                     <td colspan="2" valign="top" class="a_tit">效果监控--让您值得信赖的联盟</td>
                   </tr>
                   <tr>
                     <td width="15" height="45" class="red_dotted"></td>
                     <td>为您提供广告报告、订单报告、联盟推广合作报告等多种详细数据报告，满足您的监控需求</td>
                   </tr>
                   <tr>
                     <td width="15" height="35" class="red_dotted"></td>
                     <td>实时数据更新，监控广告效果</td>
                   </tr>
                 </table></td>
               </tr>
           </table></td>
         </tr>
     </table></td>
   </tr>
   <tr>
     <td height="30">&nbsp;</td>
   </tr>
   <tr>
     <td><table width="100%" border="0" cellpadding="0" cellspacing="0">
         <tr>
           <td width="70" height="25"><span class="title">投放流程</span></td>
           <td>&nbsp;</td>
         </tr>
         <tr>
           <td class="title_td_1"></td>
           <td class="title_td_2"></td>
         </tr>
         <tr>
           <td colspan="2">&nbsp;</td>
         </tr>
         <tr>
           <td colspan="2"><img src="<?php echo SRC_TPL_DIR?>/images/advertiser_05.jpg" /></td>
         </tr>
     </table></td>
   </tr>
   <tr>
     <td> </td>
   </tr>
 </table>
 <?php TPL::display('footer');?>
