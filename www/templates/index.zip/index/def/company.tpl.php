<?php if(!defined('IN_ZYADS')) exit(); 
TPL::display('header');
?>
 <title>关于我们 <?php echo $GLOBALS['C_ZYIIS']['sitename']?></title>

<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" class="b_bc">
  <tr>
    <td><table width="960" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td height="150" ><img src="<?php echo SRC_TPL_DIR?>/images/contact.jpg" border="0" align="absmiddle" /></td>
        </tr>
      </table></td>
  </tr>
  <tr></tr>
</table>
 <table width="960" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:30px">
   <tr>
     <td><table width="100%" border="0" cellpadding="0" cellspacing="0">
         <tr>
           <td width="70" height="25"><span class="title">关于我们</span></td>
           <td>&nbsp;</td>
         </tr>
         <tr>
           <td class="title_td_1"></td>
           <td class="title_td_2"></td>
         </tr>
     </table></td>
   </tr>
   <tr>
     <td>&nbsp;</td>
   </tr>
   <tr>
     <td height="30" style="line-height:22px"><span><?php echo $GLOBALS['C_ZYIIS']['sitename']?>是一家专注于互联网广告及网络营销领域的互联网营销公司，有着非常丰富的网络广告和网络策划经验，专注于网络广告的研究与发展，为客户提供各种形式的网络广告投放服务。其对垂直行业门户站点及娱乐性、交友性等网站也有着丰富的运营经验。<?php echo $GLOBALS['C_ZYIIS']['sitename']?>目前自身站点alexa排名在1000名左右，每天的广告显示量达到8000万次。通过<?php echo $GLOBALS['C_ZYIIS']['sitename']?>全体的努力，在国内网络广告领域已经享有良好的声誉以及品牌。<?php echo $GLOBALS['C_ZYIIS']['sitename']?>将本着“用专业的心，做专业的事”的工作原则，在良好的管理体系下，始终坚持“质优价廉”的产品价格体系，为客户真正做到省心，省钱。</span></td>
   </tr>
 </table>
 
