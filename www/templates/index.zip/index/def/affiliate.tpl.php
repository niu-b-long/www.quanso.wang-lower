<?php if(!defined('IN_ZYADS')) exit(); 
TPL::display('header');
?>
 
<title>网站主</title>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" class="b_bc">
  <tr>
    <td><table width="960" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td height="150" ><img src="<?php echo SRC_TPL_DIR?>/images/a2.jpg" border="0" align="absmiddle" /></td>
        </tr>
      </table></td>
  </tr>
  <tr></tr>
</table>
 <table width="960" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:30px; margin-bottom:30px">
   <tr>
     <td><table width="100%" border="0" cellpadding="0" cellspacing="0">
         <tr>
           <td width="70" height="25"><span class="title">网站主</span></td>
           <td>&nbsp;</td>
         </tr>
         <tr>
           <td class="title_td_1"></td>
           <td class="title_td_2"></td>
         </tr>
     </table></td>
   </tr>
   <tr>
     <td><table width="100%" border="0" cellpadding="0" cellspacing="0">
         <tr>
           <td height="50"> 在自已网站上投放广通过本平台收取佣金。</td>
         </tr>
         <tr>
           <td><table width="100%" border="0" cellpadding="0" cellspacing="0">
               <tr>
                 <td width="50" height="80"><img src="<?php echo SRC_TPL_DIR?>/images/affiliate_01.jpg" /></td>
                 <td valign="top"><table width="85%" border="0" align="center" cellpadding="0" cellspacing="0">
                   <tr>
                     <td colspan="2"><h3>丰富多样的广告形式模式</h3></td>
                    </tr>
                   <tr>
                     <td width="15" height="45" class="red_dotted"></td>
                     <td>弹窗、图片、Flash、富媒体、网摘、对联、主题多种类型的广告形式</td>
                    </tr>
                 </table>                 </td>
                 <td width="50"><img src="<?php echo SRC_TPL_DIR?>/images/affiliate_02.jpg" /></td>
                 <td valign="top"><table width="85%" border="0" align="center" cellpadding="0" cellspacing="0">
                   <tr>
                     <td colspan="2"><h3>便捷广告位的管理</h3></td>
                   </tr>
                   <tr>
                     <td width="15" height="35" class="red_dotted"></td>
                     <td>一个广告位智能轮播广告，后台管理随时增加、删除合适广告</td>
                   </tr>
                 </table></td>
               </tr>
               <tr>
                 <td><img src="<?php echo SRC_TPL_DIR?>/images/affiliate_03.jpg" /></td>
                 <td valign="top"><table width="85%" border="0" align="center" cellpadding="0" cellspacing="0">
                   <tr>
                     <td colspan="2"><h3>公品、公正放心信誉</h3></td>
                   </tr>
                   <tr>
                     <td width="15" height="35" class="red_dotted"></td>
                     <td>雄厚的资金支持，完善的支付系统，保证你的收入准确，及时到帐</td>
                   </tr>
                 </table></td>
                 <td><img src="<?php echo SRC_TPL_DIR?>/images/affiliate_04.jpg" /></td>
                 <td valign="top"><table width="85%" border="0" align="center" cellpadding="0" cellspacing="0">
                   <tr>
                     <td colspan="2"><h3>成熟、先进的系统</h3></td>
                   </tr>
                   <tr>
                     <td width="15" height="35" class="red_dotted"></td>
                     <td>成熟、先进的系统及商业运作模式，使你操作更简单，赚钱更快</td>
                   </tr>
                 </table></td>
               </tr>
           </table></td>
         </tr>
     </table></td>
   </tr>
   <tr>
     <td height="30">&nbsp;</td>
   </tr>
   <tr>
     <td>&nbsp;</td>
   </tr>
   <tr>
     <td> </td>
   </tr>
 </table>
 <?php TPL::display('footer');?>
