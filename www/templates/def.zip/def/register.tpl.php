<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>用户注册</title>
    <meta http-equiv="Cache-Control" content="no-transform" />
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=yes" />
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="./templates/index/def/static/css/bootstrap.min.css">
    <link rel="stylesheet" href="./templates/index/def/static/css/iconfont.css">
    <link rel="shortcut icon" href="/html/v2016/7cx_v2018/bitbug_favicon.ico" />
    <link rel="stylesheet" href="./templates/index/def/static/css/mobliemenu.css">
    <link rel="stylesheet" href="./templates/index/def/static/css/all.css">
	<script src="./templates/index/def/static/js/jquery-1.12.4.min.js"></script>
	<script src="./templates/index/def/static/js/tether.min.js"></script>
	<script src="./templates/index/def/static/js/bootstrap.min.js"></script>
	<script src="./templates/index/def/static/js/jqthumb.min.js"></script>
	<script src="./templates/index/def/static/js/mobliemenu.js"></script>
	<script src="./templates/index/def/static/js/gverify.js"></script>
	<script src="./templates/index/def/static/js/all.js"></script>
</head>
<body class="login-page">
    <div class="logo"><a href="/"><img src="" alt=""></a></div>
    <div class="con register">
        <div class="top">
            <h5>用户注册</h5>
			<form id="form_register" action="<?php echo url("index.post_register");?>" method="POST">
			<input type="hidden" name="ajax_do" value="1">
			<input type="hidden" name="service_id" value="0">
			<input type="hidden" name="reg_platform" value="" id="reg_platform">
            <div class="check">
                <div class="form_cont">
                    <div class="custom-control custom-radio custom-control-inline">
                        <input type="radio" id="customRadioInline1" name="type" value="2" class="custom-control-input web juser_type" checked>
                        <label class="custom-control-label" for="customRadioInline1">网站主</label>
                    </div>
                    <div class="custom-control custom-radio custom-control-inline">
                        <input type="radio" id="customRadioInline2" name="type" value="1" class="custom-control-input advert juser_type">
                        <label class="custom-control-label" for="customRadioInline2">广告主</label>
                    </div>
                </div>
                <div class="input">
					<div class="list">
						<p>用户名</p>
						<input type="text" name="username" placeholder="请输入用户名">
					</div>
					<div class="list">
						<p>密码</p>
						<input type="password" name="password" placeholder="请输入6-15个英文字母或数字的组合字符">
					</div>
					<div class="list">
						<p>确认密码</p>
						<input type="password" name="password_confirm" placeholder="请再输入一次密码">
					</div>
					<!-- <div class="list" style="display:none" id="show_company_name">
						<p>公司名称</p>
						<input type="text" name="company_name" placeholder="请输入公司名称">
					</div>
					<div class="list" style="display:none" id="show_company_domain">
						<p>官网域名</p>
						<input type="text" name="company_domain" placeholder="请输入官网域名">
					</div> -->
					<div class="list">
						<p>QQ</p>
						<input type="text" name="qq" onkeyup="value=value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))" placeholder="请输入常用QQ号码，找回密码需要">
					</div>
					<div class="list">
						<p>手机号码</p>
						<input type="text" name="contact" onkeyup="value=value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))" placeholder="请输入常用手机号，方便及时与您联系">
					</div>
					<input type="submit" class="log jbtn_register" value="注 册" />
				</div>
            </div>
			</form>
        </div>
        <div class="bottom">
			<p>已有账号？<a href="index.php?e=index.login">立即登录</a></p>
		</div>
    </div>
    <!--con-->
    <p class="copy">&copy;2019 uu2o.com 版权所有 服务热线：xxxxxxxxxxx </p>
    <!-- jQuery first, then Tether, then Bootstrap JS. -->
	<script type="text/javascript" src="./templates/index/def/static/js/auth.js"></script>
	<script type="text/javascript">
	var TYPE = 0;
	Auth.event_register_email();
	</script>
</body>
</html>