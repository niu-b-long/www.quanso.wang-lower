<div class="footer">
	<div class="container">
		<div class="top">
			<div class="left-con">
				<figure class="logo"><img src="./templates/index/def/static/picture/logo.png" alt="" width="172" height="43"></figure>
				<div class="right">
					<!--<figure class="code"><img src="./templates/index/def/static/picture/1534490114.png" alt=""></figure>-->
					<div class="con">
						<p>投诉建议：84166010</p>
						<p style="display: inline-block;">媒介QQ：<span style="display: inline-block;"><a target="_blank" href="http://wpa.qq.com/msgrd?v=1&amp;uin=00000000&amp;site=投诉建议&amp;menu=yes"><img alt="QQ" src="./templates/index/def/static/picture/68d889a0d00f407cb5c2dcc485e88e4b.gif" border="0" height="16" style="display: inline-block;margin-right: 3px;">442085389</a></span>     
         			    </p>
         			    <p style="display: inline-block;"><span style="display: inline-block;"><a target="_blank" href="http://wpa.qq.com/msgrd?v=1&amp;uin=00000000&amp;site=投诉建议&amp;menu=yes"><img alt="QQ" src="./templates/index/def/static/picture/68d889a0d00f407cb5c2dcc485e88e4b.gif" border="0" height="16" style="display: inline-block;margin-right: 3px;">434329916</a></span>     
         			    </p>
         			    <p style="display: inline-block;"><span style="display: inline-block;"><a target="_blank" href="http://wpa.qq.com/msgrd?v=1&amp;uin=00000000&amp;site=投诉建议&amp;menu=yes"><img alt="QQ" src="./templates/index/def/static/picture/68d889a0d00f407cb5c2dcc485e88e4b.gif" border="0" height="16" style="display: inline-block;margin-right: 3px;">74835782</a></span>     
         			    </p>
         			    <p style="display: inline-block;"><span style="display: inline-block;"><a target="_blank" href="http://wpa.qq.com/msgrd?v=1&amp;uin=00000000&amp;site=投诉建议&amp;menu=yes"><img alt="QQ" src="./templates/index/def/static/picture/68d889a0d00f407cb5c2dcc485e88e4b.gif" border="0" height="16" style="display: inline-block;margin-right: 3px;">748360244</a></span>     
         			    </p>
         			    <p style="display: inline-block;"><span style="display: inline-block;"><a target="_blank" href="http://wpa.qq.com/msgrd?v=1&amp;uin=00000000&amp;site=投诉建议&amp;menu=yes"><img alt="QQ" src="./templates/index/def/static/picture/68d889a0d00f407cb5c2dcc485e88e4b.gif" border="0" height="16" style="display: inline-block;margin-right: 3px;">463782751</a></span>     
         			    </p>
         			    <p style="display: inline-block;"><span style="display: inline-block;"><a target="_blank" href="http://wpa.qq.com/msgrd?v=1&amp;uin=00000000&amp;site=投诉建议&amp;menu=yes"><img alt="QQ" src="./templates/index/def/static/picture/68d889a0d00f407cb5c2dcc485e88e4b.gif" border="0" height="16" style="display: inline-block;margin-right: 3px;">466173899</a></span>     
         			    </p>
         			    <p style="display:block;">广告主联系QQ：<span style="display: inline-block;"><a target="_blank" href="http://wpa.qq.com/msgrd?v=1&amp;uin=00000000&amp;site=投诉建议&amp;menu=yes"><img alt="QQ" src="./templates/index/def/static/picture/68d889a0d00f407cb5c2dcc485e88e4b.gif" border="0" height="16" style="display: inline-block;margin-right: 3px;">458410334</a></span>     
         			    </p>
         			    <p style="display: inline-block;"><span style="display: inline-block;"><a target="_blank" href="http://wpa.qq.com/msgrd?v=1&amp;uin=00000000&amp;site=投诉建议&amp;menu=yes"><img alt="QQ" src="./templates/index/def/static/picture/68d889a0d00f407cb5c2dcc485e88e4b.gif" border="0" height="16" style="display: inline-block;margin-right: 3px;">460690758</a></span>     
         			    </p>
					</div>
				</div>
			</div>
		</div>
		<p class="copy">
		&copy;2019 uu2o.com 版权所有 <a href="http://www.miitbeian.gov.cn/" target="_blank">粤ICP备16003346号-11</a>  <!-- <script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1273048078'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s22.cnzz.com/z_stat.php%3Fid%3D1273048078%26show%3Dpic1' type='text/javascript'%3E%3C/script%3E"));</script> -->
		</p>
	</div>
</div>
